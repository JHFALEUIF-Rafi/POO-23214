package modelo;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import org.mindrot.jbcrypt.BCrypt;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    private final DBCollection coleccion;

    public UsuarioDAO() {
        try {
            MongoClient mongo = ConexionMongoDB.getInstancia();
            DB db = mongo.getDB("sistema_sismico");
            this.coleccion = db.getCollection("usuarios");
            crearIndices(); // Asegura índices al iniciar
        } catch (MongoException e) {
            throw new RuntimeException("Error al conectar con MongoDB: " + e.getMessage(), e);
        }
    }

    private void crearIndices() {
        // Índice único para username
        coleccion.createIndex(new BasicDBObject("username", 1), new BasicDBObject("unique", true));
    }

    public Usuario buscarPorUsername(String username) {
        try {
            BasicDBObject query = new BasicDBObject("username", username.toLowerCase()); // Búsqueda case-insensitive
            DBObject doc = coleccion.findOne(query);
            return (doc != null) ? Usuario.fromDBObject((BasicDBObject) doc) : null;
        } catch (MongoException e) {
            throw new RuntimeException("Error al buscar usuario: " + e.getMessage(), e);
        }
    }

    public void guardarUsuario(Usuario usuario) {
        try {
            // Validar si el usuario ya existe
            if (buscarPorUsername(usuario.getUsername()) != null) {
                throw new RuntimeException("El usuario ya existe");
            }

            // Hashear la contraseña antes de guardar
            usuario.setPasswordHash(BCrypt.hashpw(usuario.getPassword(), BCrypt.gensalt()));

            BasicDBObject doc = usuario.toDBObject();
            coleccion.insert(doc);
        } catch (MongoException e) {
            throw new RuntimeException("Error al guardar usuario: " + e.getMessage(), e);
        }
    }

    public boolean autenticar(String username, String password) {
        Usuario usuario = buscarPorUsername(username);
        return usuario != null && BCrypt.checkpw(password, usuario.getPasswordHash());
    }

    public List<Usuario> listarTodos() {
        List<Usuario> usuarios = new ArrayList<>();
        try (DBCursor cursor = coleccion.find()) {
            while (cursor.hasNext()) {
                usuarios.add(Usuario.fromDBObject((BasicDBObject) cursor.next()));
            }
        }
        return usuarios;
    }

    // Método para el administrador (opcional)
    public void eliminarUsuario(String username) {
        try {
            BasicDBObject query = new BasicDBObject("username", username);
            coleccion.remove(query);
        } catch (MongoException e) {
            throw new RuntimeException("Error al eliminar usuario: " + e.getMessage(), e);
        }
    }
}
