package modelo;

import java.awt.List;

public class Volcan {

    private String nombre;
    private double VEI;
    private List<Erupcion> historico;
}
