package modelo;

import com.mongodb.BasicDBObject;
import org.mindrot.jbcrypt.BCrypt;

public class Usuario {

    private String username;
    private String passwordHash; // Nunca almacenar contraseñas en texto plano
    private String rol; // "ADMIN", "CIENTIFICO", "TECNICO", "OPERADOR"

    // Constructor para nuevos usuarios (hashea la contraseña)
    public Usuario(String username, String password, String rol) {
        this.username = username.toLowerCase(); // Normalización
        this.passwordHash = BCrypt.hashpw(password, BCrypt.gensalt());
        this.rol = rol.toUpperCase();
    }

    // Constructor desde MongoDB (ya tiene hash)
    public Usuario(String username, String passwordHash, String rol) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.rol = rol;
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public String getRol() {
        return rol;
    }

    // Setters
    public void setPasswordHash(String hash) {
        this.passwordHash = hash;
    }

    // MongoDB Integration
    public BasicDBObject toDBObject() {
        return new BasicDBObject()
                .append("username", username)
                .append("passwordHash", passwordHash)
                .append("rol", rol);
    }

    public static Usuario fromDBObject(BasicDBObject doc) {
        return new Usuario(
                doc.getString("username"),
                doc.getString("passwordHash"),
                doc.getString("rol")
        );
    }
}
