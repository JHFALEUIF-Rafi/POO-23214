package modelo;

public class Alerta {
   public void notificarEmergencia(String mensaje) { /* Enviar email/SMS */ } 
}
