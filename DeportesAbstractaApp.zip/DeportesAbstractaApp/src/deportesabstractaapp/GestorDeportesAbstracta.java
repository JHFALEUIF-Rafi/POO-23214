/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deportesabstractaapp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author tatianagualotuna
 */
public class GestorDeportesAbstracta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        List <Edificio> listaP;
    
        listaP = new ArrayList <Edificio>();

        Polideportivo pd1 = new Polideportivo(500, 100, "abierto", "Poli 1");
        Polideportivo pd2 = new Polideportivo(1410, 500, "cerrado", "Poli 2");
        Polideportivo pd3 = new Polideportivo(1800, 300, "semiabierto", "Poli 3");
        
        EdificioOficinas eo1 = new EdificioOficinas(500,400, 7, 5);
        EdificioOficinas eo2 = new EdificioOficinas(1500,700, 10, 14);
        
       
        
        listaP.add(pd1);
        listaP.add(pd2);
        listaP.add(pd3);
        listaP.add(eo1);
        listaP.add(eo2);
          
        Iterator objIt = listaP.iterator();
        
        while(objIt.hasNext())
        {
            Edificio aux =(Edificio) objIt.next();
           // System.out.println(aux.toString());
           System.out.println("La superficie es: " + aux.getSuperficieEdificio());
           
        }
    }
    
}
