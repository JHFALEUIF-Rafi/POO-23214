/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deportesabstractaapp;

/**
 *
 * @author tatianagualotuna
 */
public class Polideportivo implements InstalacionDeportiva, Edificio {
    
    private double largo;
    private double ancho;
    private String tipo;
    private String nombre;

    public Polideportivo(double largo, double ancho, String tipo, String nombre) {
        this.largo = largo;
        this.ancho = ancho;
        this.tipo = tipo;
        this.nombre = nombre;
    }

    public double getLargo() {
        return largo;
    }

    public void setLargo(double largo) {
        this.largo = largo;
    }

    public double getAncho() {
        return ancho;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Polideportivo{" + "largo=" + largo + ", ancho=" + ancho + ", tipo=" + tipo + ", nombre=" + nombre + '}';
    }

    
    
    @Override
    public int getTipoInstalacion() {
         if(this.tipo.equals("abierto"))
        {
            return 1;
        }
        else if(this.tipo.equals("cerrado"))
        {
            return 2;
        }
        else return 3;
    }

    @Override
    public double getSuperficieEdificio() {
         return largo * ancho;
    }
    
}
