/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deportesabstractaapp;

/**
 *
 * @author tatianagualotuna
 */
public class EdificioOficinas implements Edificio {

    private double largo;
    private double ancho;
    private int numeroOficinas;
    private int numeroPisos;

    public EdificioOficinas(double largo, double ancho, int numeroOficinas, int numeroPisos) {
        this.largo = largo;
        this.ancho = ancho;
        this.numeroOficinas = numeroOficinas;
        this.numeroPisos = numeroPisos;
    }

    public double getLargo() {
        return largo;
    }

    public void setLargo(double largo) {
        this.largo = largo;
    }

    public double getAncho() {
        return ancho;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public int getNumeroOficinas() {
        return numeroOficinas;
    }

    public void setNumeroOficinas(int numeroOficinas) {
        this.numeroOficinas = numeroOficinas;
    }

    public int getNumeroPisos() {
        return numeroPisos;
    }

    public void setNumeroPisos(int numeroPisos) {
        this.numeroPisos = numeroPisos;
    }

    @Override
    public String toString() {
        return "EdificioOficinas{" + "largo=" + largo + ", ancho=" + ancho + ", numeroOficinas=" + numeroOficinas + ", numeroPisos=" + numeroPisos + '}';
    }
    
    
    @Override
    public double getSuperficieEdificio() {
         return largo * ancho * numeroPisos;
    }
    
}
